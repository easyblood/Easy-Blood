import express from "express";
import cors from "cors";
import bcrypt from "bcryptjs";
import jwt from "jsonwebtoken";
import Database from "better-sqlite3";
import multer from "multer";
import crypto from "crypto";
import path from "path";
import fs from "fs";
import PDFDocument from "pdfkit";
import QRCode from "qrcode";

const app = express();
const PORT = Number(process.env.PORT || 3000);
const JWT_SECRET = process.env.JWT_SECRET || "CHANGE_THIS_SECRET_BEFORE_PRODUCTION";
const PUBLIC_BASE_URL = process.env.PUBLIC_BASE_URL || `http://localhost:${PORT}`;

app.use(cors());
app.use(express.json({ limit: "4mb" }));

const dataDir = path.resolve(process.env.DATA_DIR || ".");
fs.mkdirSync(dataDir, { recursive: true });
const db = new Database(path.join(dataDir, process.env.DB_FILE || "easyblood.db"));
db.pragma("journal_mode = WAL");
db.exec(`
CREATE TABLE IF NOT EXISTS users (
 id INTEGER PRIMARY KEY AUTOINCREMENT,
 login_id TEXT UNIQUE NOT NULL,
 password_hash TEXT NOT NULL,
 role TEXT NOT NULL CHECK(role IN ('management','staff')),
 active INTEGER NOT NULL DEFAULT 1,
 created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);
CREATE TABLE IF NOT EXISTS patients (
 id INTEGER PRIMARY KEY AUTOINCREMENT,
 patient_id TEXT UNIQUE NOT NULL,
 name TEXT NOT NULL,
 age TEXT DEFAULT '',
 gender TEXT DEFAULT '',
 mobile TEXT DEFAULT '',
 created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);
CREATE TABLE IF NOT EXISTS reports (
 id INTEGER PRIMARY KEY AUTOINCREMENT,
 report_id TEXT UNIQUE NOT NULL,
 patient_id TEXT NOT NULL,
 patient_name TEXT NOT NULL,
 age TEXT DEFAULT '',
 gender TEXT DEFAULT '',
 mobile TEXT DEFAULT '',
 test_name TEXT NOT NULL,
 result_json TEXT NOT NULL,
 barcode TEXT,
 report_date TEXT NOT NULL,
 verified INTEGER NOT NULL DEFAULT 1,
 pdf_url TEXT,
 verify_token TEXT UNIQUE NOT NULL,
 created_by INTEGER,
 created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);
CREATE INDEX IF NOT EXISTS idx_reports_patient ON reports(patient_id);
CREATE INDEX IF NOT EXISTS idx_reports_date ON reports(report_date);
`);

if (!db.prepare("SELECT 1 FROM users LIMIT 1").get()) {
  const mg = bcrypt.hashSync(process.env.MANAGEMENT_PASSWORD || "easyblood123", 12);
  db.prepare("INSERT INTO users(login_id,password_hash,role) VALUES(?,?,?)").run("easyblood", mg, "management");
}

const uploadDir = path.resolve(dataDir, "uploads");
fs.mkdirSync(uploadDir, { recursive: true });
const upload = multer({
  dest: uploadDir,
  limits: { fileSize: 15 * 1024 * 1024 },
  fileFilter: (req, file, cb) => cb(null, file.mimetype === "application/pdf")
});

function auth(req, res, next) {
  const h = req.headers.authorization || "";
  if (!h.startsWith("Bearer ")) return res.status(401).json({ error: "Unauthorized" });
  try { req.user = jwt.verify(h.slice(7), JWT_SECRET); next(); }
  catch { return res.status(401).json({ error: "Invalid or expired token" }); }
}
function management(req, res, next) {
  if (req.user.role !== "management") return res.status(403).json({ error: "Management access required" });
  next();
}
function makeId(prefix, bytes = 5) { return `${prefix}-${crypto.randomBytes(bytes).toString("hex").toUpperCase()}`; }
function normalizeResults(result) {
  if (!Array.isArray(result)) return [];
  return result.map(x => ({
    parameter: String(x.parameter ?? x.name ?? ""),
    value: String(x.value ?? ""),
    unit: String(x.unit ?? ""),
    reference: String(x.reference ?? x.range ?? "")
  })).filter(x => x.parameter);
}

app.get("/api/health", (req, res) => res.json({ ok: true, service: "Easy Blood", time: new Date().toISOString() }));

app.post("/api/auth/login", (req, res) => {
  const { login_id, password } = req.body || {};
  const u = db.prepare("SELECT * FROM users WHERE login_id=? AND active=1").get(login_id || "");
  if (!u || !bcrypt.compareSync(password || "", u.password_hash)) return res.status(401).json({ error: "Incorrect Login ID or Password" });
  const token = jwt.sign({ id: u.id, login_id: u.login_id, role: u.role }, JWT_SECRET, { expiresIn: "8h" });
  res.json({ token, role: u.role, login_id: u.login_id });
});

app.get("/api/me", auth, (req, res) => res.json({ id: req.user.id, login_id: req.user.login_id, role: req.user.role }));

app.post("/api/users", auth, management, (req, res) => {
  const { login_id, password, role = "staff" } = req.body || {};
  if (!login_id || !password || role !== "staff") return res.status(400).json({ error: "Invalid user" });
  try {
    const hash = bcrypt.hashSync(password, 12);
    const info = db.prepare("INSERT INTO users(login_id,password_hash,role) VALUES(?,?,?)").run(login_id.trim(), hash, role);
    res.status(201).json({ id: info.lastInsertRowid, login_id: login_id.trim(), role });
  } catch { res.status(409).json({ error: "Login ID already exists" }); }
});

app.get("/api/patients", auth, (req, res) => {
  const q = String(req.query.q || "").trim();
  const rows = q
    ? db.prepare("SELECT * FROM patients WHERE patient_id LIKE ? OR name LIKE ? OR mobile LIKE ? ORDER BY id DESC LIMIT 100").all(`%${q}%`, `%${q}%`, `%${q}%`)
    : db.prepare("SELECT * FROM patients ORDER BY id DESC LIMIT 100").all();
  res.json(rows);
});

app.post("/api/patients", auth, (req, res) => {
  const r = req.body || {};
  if (!r.name) return res.status(400).json({ error: "Patient name is required" });
  const patientId = r.patient_id || makeId("EBP");
  try {
    db.prepare("INSERT INTO patients(patient_id,name,age,gender,mobile) VALUES(?,?,?,?,?)").run(patientId, r.name.trim(), r.age || "", r.gender || "", r.mobile || "");
    res.status(201).json({ patient_id: patientId });
  } catch { res.status(409).json({ error: "Patient ID already exists" }); }
});

app.post("/api/reports", auth, (req, res) => {
  const r = req.body || {};
  if (!r.patient_name || !r.test_name) return res.status(400).json({ error: "Patient name and test name are required" });
  const reportId = r.report_id || makeId("EBR", 6);
  const patientId = r.patient_id || makeId("EBP");
  const token = crypto.randomBytes(24).toString("base64url");
  const results = normalizeResults(r.result);
  db.prepare(`INSERT INTO reports
    (report_id,patient_id,patient_name,age,gender,mobile,test_name,result_json,barcode,report_date,verify_token,created_by)
    VALUES(?,?,?,?,?,?,?,?,?,?,?,?)`).run(
    reportId, patientId, r.patient_name.trim(), r.age || "", r.gender || "", r.mobile || "", r.test_name.trim(),
    JSON.stringify(results), r.barcode || reportId, r.report_date || new Date().toISOString().slice(0,10), token, req.user.id
  );
  res.status(201).json({ report_id: reportId, patient_id: patientId, verify_url: `${PUBLIC_BASE_URL}/patient-report.html?token=${encodeURIComponent(token)}` });
});

app.get("/api/reports", auth, (req, res) => {
  const q = String(req.query.q || "").trim();
  const rows = q
    ? db.prepare(`SELECT report_id,patient_id,patient_name,age,gender,test_name,barcode,report_date,verified,pdf_url,created_at
                  FROM reports WHERE report_id LIKE ? OR patient_name LIKE ? OR patient_id LIKE ? OR mobile LIKE ? ORDER BY id DESC LIMIT 200`).all(`%${q}%`,`%${q}%`,`%${q}%`,`%${q}%`)
    : db.prepare(`SELECT report_id,patient_id,patient_name,age,gender,test_name,barcode,report_date,verified,pdf_url,created_at FROM reports ORDER BY id DESC LIMIT 200`).all();
  res.json(rows);
});

app.get("/api/reports/:reportId", auth, (req, res) => {
  const r = db.prepare("SELECT * FROM reports WHERE report_id=?").get(req.params.reportId);
  if (!r) return res.status(404).json({ error: "Report not found" });
  r.result = JSON.parse(r.result_json); delete r.result_json; delete r.verify_token;
  r.verify_url = `${PUBLIC_BASE_URL}/patient-report.html?token=${encodeURIComponent(db.prepare("SELECT verify_token FROM reports WHERE report_id=?").get(req.params.reportId).verify_token)}`;
  res.json(r);
});

app.get("/api/reports/verify/:token", (req, res) => {
  const r = db.prepare("SELECT report_id,patient_id,patient_name,age,gender,mobile,test_name,result_json,barcode,report_date,verified,pdf_url FROM reports WHERE verify_token=? AND verified=1").get(req.params.token);
  if (!r) return res.status(404).json({ error: "Report not found or not verified" });
  r.result = JSON.parse(r.result_json); delete r.result_json;
  if (r.pdf_url) r.pdf_url = `${PUBLIC_BASE_URL}${r.pdf_url}`;
  res.json(r);
});

app.post("/api/reports/:reportId/pdf", auth, upload.single("pdf"), (req, res) => {
  if (!req.file) return res.status(400).json({ error: "PDF required" });
  const r = db.prepare("SELECT id FROM reports WHERE report_id=?").get(req.params.reportId);
  if (!r) return res.status(404).json({ error: "Report not found" });
  const publicUrl = `/uploads/${path.basename(req.file.path)}`;
  db.prepare("UPDATE reports SET pdf_url=? WHERE report_id=?").run(publicUrl, req.params.reportId);
  res.json({ pdf_url: `${PUBLIC_BASE_URL}${publicUrl}` });
});

app.post("/api/reports/:reportId/generate-pdf", auth, async (req, res) => {
  const r = db.prepare("SELECT * FROM reports WHERE report_id=?").get(req.params.reportId);
  if (!r) return res.status(404).json({ error: "Report not found" });
  const results = JSON.parse(r.result_json);
  const token = r.verify_token;
  const verifyUrl = `${PUBLIC_BASE_URL}/patient-report.html?token=${encodeURIComponent(token)}`;
  const fileName = `${r.report_id}.pdf`;
  const filePath = path.join(uploadDir, fileName);
  const qrData = await QRCode.toDataURL(verifyUrl, { margin: 1, width: 150 });
  const doc = new PDFDocument({ margin: 45 });
  const stream = fs.createWriteStream(filePath);
  doc.pipe(stream);
  doc.fontSize(22).text("EASY BLOOD", { align: "center" });
  doc.fontSize(10).text("LABORATORY REPORT", { align: "center" });
  doc.moveDown();
  doc.fontSize(10).text(`Report ID: ${r.report_id}`);
  doc.text(`Patient ID: ${r.patient_id}`);
  doc.text(`Patient Name: ${r.patient_name}`);
  doc.text(`Age / Gender: ${r.age || "-"} / ${r.gender || "-"}`);
  doc.text(`Mobile: ${r.mobile || "-"}`);
  doc.text(`Test: ${r.test_name}`);
  doc.text(`Report Date: ${r.report_date}`);
  doc.moveDown();
  doc.fontSize(12).text("Test Results", { underline: true });
  doc.moveDown(0.4);
  for (const x of results) doc.fontSize(10).text(`${x.parameter}: ${x.value} ${x.unit}    Reference: ${x.reference}`);
  doc.moveDown();
  doc.fontSize(9).text("Scan the QR code to verify this report online.");
  const base64 = qrData.split(",")[1];
  const qrFile = path.join(uploadDir, `${r.report_id}-qr.png`);
  fs.writeFileSync(qrFile, Buffer.from(base64, "base64"));
  doc.image(qrFile, { width: 110 });
  doc.end();
  stream.on("finish", () => {
    const publicUrl = `/uploads/${fileName}`;
    db.prepare("UPDATE reports SET pdf_url=? WHERE report_id=?").run(publicUrl, r.report_id);
    res.json({ pdf_url: `${PUBLIC_BASE_URL}${publicUrl}`, verify_url: verifyUrl });
  });
  stream.on("error", () => res.status(500).json({ error: "PDF generation failed" }));
});

app.use("/uploads", express.static(uploadDir, { index: false }));
app.use(express.static(path.resolve(".")));
app.get("/", (req, res) => res.sendFile(path.resolve("lab-management.html")));
app.listen(PORT, () => console.log(`Easy Blood API running on port ${PORT}`));
