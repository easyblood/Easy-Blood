// Function to toggle the mobile menu
function toggleMenu() {
    const navbarLinks = document.getElementById('navbar-links');
    const hamburger = document.querySelector('.hamburger-menu');
    
    navbarLinks.classList.toggle('active');
    hamburger.classList.toggle('open');
}

// Close the menu when clicking outside of the menu
document.addEventListener('click', function(event) {
    const navbarLinks = document.getElementById('navbar-links');
    const hamburger = document.querySelector('.hamburger-menu');
    const menu = navbarLinks.querySelector('ul');

    // Check if the click is outside the navbar and hamburger menu
    if (!navbarLinks.contains(event.target) && !hamburger.contains(event.target) && !menu.contains(event.target)) {
        navbarLinks.classList.remove('active');
        hamburger.classList.remove('open');
    }
});

// Function to toggle the cart popup visibility
function toggleCartPopup(event) {
    event.stopPropagation();  // Prevent the click event from propagating to the document

    const cartPopup = document.getElementById('cart-popup');

    // Toggle the popup visibility
    if (cartPopup.classList.contains('active')) {
        // If the cart is already open, don't toggle it again, just ensure it's closed
        cartPopup.classList.remove('active');
    } else {
        // If the cart is closed, make sure other popups are closed (if any)
        closeOtherPopups();
        cartPopup.classList.add('active');
    }
}
// when click on close button
function closeCartPopup() {
    const cartPopup = document.getElementById('cart-popup');
    cartPopup.classList.remove('active'); // Remove the 'active' class to hide the popup
}

// Close any other open popups (to handle multiple potential popups)
function closeOtherPopups() {
    const cartPopup = document.getElementById('cart-popup');
    cartPopup.classList.remove('active');
}

// Close the cart popup when clicking outside
document.addEventListener('click', function(event) {
    const cartPopup = document.getElementById('cart-popup');
    const cartIcon = document.querySelector('.cart-icon');

    // Check if the click was outside the cart icon and the cart popup
    if (!cartPopup.contains(event.target) && !cartIcon.contains(event.target)) {
        cartPopup.classList.remove('active');
    }
});




// Blood Test Data
const bloodTestsByLab = {
    "thyrocare": [
        { "name": "17-OH Progesterone", "price": 770 },
{ "name": "Activated Partial Thromboplastin Time (aPTT)", "price": 499 },
{ "name": "Albumin", "price": 200 },
{ "name": "Albumin/Globulin Ratio", "price": 300 },
{ "name": "Alkaline Phosphatase (ALP)", "price": 210 },
{ "name": "Alkaline Phosphatase Isoenzymes", "price": 5600 },
{ "name": "Alpha-1 Antitrypsin Test", "price": 1240 },
{ "name": "Alpha-fetoprotein (AFP)", "price": 740 },
{ "name": "Amylase", "price": 520 },
{ "name": "ANA Test (Antinuclear Antibody)", "price": 750 },
{ "name": "Anti-Phospholipid Antibody IgG Test", "price": 870 },
{ "name": "Anti-Phospholipid Antibody IgM Test", "price": 870 },
{ "name": "Anti-CCP (Anti-Cyclic Citrullinated Peptide)", "price": 1700 },
{ "name": "Anti-DsDNA Test", "price": 760 },
{ "name": "Anti-Mullerian Hormone (AMH)", "price": 1970 },
{ "name": "Antibody for HIV 1/2 rapid test", "price": 480 },
{ "name": "Antenatal Care Profile (ANC) - Advance", "price": 1800 },
{ "name": "Aspartate Aminotransferase (AST/SGOT)", "price": 200 },
{ "name": "Alanine Aminotransferase (ALT/SGPT)", "price": 200 },
{ "name": "Beta-2 Microglobulin", "price": 620 },
{ "name": "Bilirubin Direct", "price": 210 },
{ "name": "Bilirubin Indirect", "price": 300 },
{ "name": "Bilirubin total Test", "price": 210 },
{ "name": "BLOOD CULTURE AND SUSCEPTIBILITY (ADULT)", "price": 820 },
{ "name": "Blood Grouping (ABO and Rh Factor)", "price": 200 },
{ "name": "Blood Lactate Test", "price": 410 },
{ "name": "Blood Lead Level", "price": 1030 },
{ "name": "Blood Sugar (Glucose Fasting)", "price": 80 },
{ "name": "Blood Sugar (Glucose PP)", "price": 80 },
{ "name": "Blood Urea Nitrogen (BUN)", "price": 110 },
{ "name": "Blood Urea Nitrogen (BUN)/Creatinine Ratio", "price": 350 },
{ "name": "Bence-Jones Protein", "price": 820 },
{ "name": "C-Reactive Protein (CRP)", "price": 480 },
{ "name": "C-reactive Protein High Sensitivity (HS-CRP)", "price": 680 },
{ "name": "Carcinoembryonic Antigen (CEA)", "price": 740 },
{ "name": "CA 125 (Cancer Antigen 125)", "price": 1270 },
{ "name": "Calcium Test", "price": 200 },
{ "name": "CBC (Complete Blood Count)", "price": 250 },
{ "name": "Chloride", "price": 200 },
{ "name": "Cholesterol total", "price": 200 },
{ "name": "Cholinesterase Test", "price": 310 },
{ "name": "Cortisol", "price": 700 },
{ "name": "Serum Creatinine", "price": 200 },
{ "name": "Cystatin C Test", "price": 520 },
{ "name": "D-dimer Test", "price": 1050 },
{ "name": "DHEA-S (Dehydroepiandrosterone sulfate)", "price": 990 },
{ "name": "DENGUE RAPID TEST (IgG/IgM)", "price": 330 },
{ "name": "Dengue NS1 Antigen", "price": 660 },
{ "name": "Dopamine Test", "price": 2400 },
{ "name": "Electrolytes (Sodium, Potassium, etc.)", "price": 460 },
{ "name": "Estradiol", "price": 570 },
{ "name": "Erythrocyte Sedimentation Rate (ESR)", "price": 120 },
{ "name": "Fecal Occult Blood Test", "price": 300 },
{ "name": "Ferritin Test", "price": 750 },
{ "name": "Folate (Vitamin B9) Test", "price": 1170 },
{ "name": "Follicle Stimulating Hormone (FSH)", "price": 480 },
{ "name": "Free Testosterone", "price": 1440 },
{ "name": "FT3 (Free Triiodothyronine)", "price": 260 },
{ "name": "FT4 (Free Thyroxine)", "price": 260 },
{ "name": "Gamma-Glutamyl Transferase (GGT)", "price": 210 },
{ "name": "Glomerular Filtration Rate (GFR)", "price": 210 },
{ "name": "Globulin", "price": 210 },
{ "name": "Glycated Hemoglobin (HbA1c)", "price": 350 },
{ "name": "G6PD Deficiency Test", "price": 700 },
{ "name": "HCG Beta", "price": 770 },
{ "name": "HELICOBACTER PYLORI - IgG", "price": 1030 },
{ "name": "HELICOBACTER PYLORI - IgM", "price": 1030 },
{ "name": "Hemoglobin", "price": 200 },
{ "name": "Hepatitis B Surface Antigen (HBsAg)", "price": 480 },
{ "name": "Hepatitis C Antibody Test", "price": 1180 },
{ "name": "HLA-B27 Test", "price": 2070 },
{ "name": "Homocysteine", "price": 1130 },
{ "name": "Immunoglobulin Levels (IgA)", "price": 770 },
{ "name": "Immunoglobulin Levels (IgG)", "price": 770 },
{ "name": "Immunoglobulin Levels (IgE)", "price": 1240},
{ "name": "Inhibin A", "price": 2060 },
{ "name": "Iron Test", "price": 200 },
{ "name": "Kidney Function Test (KFT)(RFT)",
  "price": 800 },
{ "name": "LDH (Lactate Dehydrogenase)", "price": 340 },
{ "name": "Lipase", "price": 510 },
{ "name": "Lipid Profile", "price": 550 },
{ "name": "Lipoprotein(a) Test", "price": 480 },
{ "name": "Liver Function Test (LFT)", "price": 550 },
{ "name": "Luteinizing Hormone (LH)", "price": 400 },
{ "name": "Malaria Parasite Test", "price": 150 },
{ "name": "Microscopic Urine Examination", "price": 150 },
{ "name": "Myoglobin Test", "price": 1030 },
{ "name": "PAP - PAPANICULAOU SMEAR", "price": 480 },
{ "name": "PTH (INTACT PARATHYROID HORMONE)", "price": 1440 },
{ "name": "Platelet Count", "price": 200 },
{ "name": "Potassium", "price": 200 },
{ "name": "Procalcitonin Test", "price": 1300 },
{ "name": "Prolactin Test", "price": 530 },
{ "name": "Prostate-Specific Antigen (PSA)", "price": 600 },
{ "name": "Protein Electrophoresis (Serum)", "price": 820 },
{ "name": "QuantiFERON - TB", "price": 1500 },
{ "name": "RA (Rheumatoid Factor)", "price": 600 },
{ "name": "Serum Acetaminophen (Paracetamol) Levels", "price": 1000 },
{ "name": "Serum Creatine Phosphokinase (CPK)", "price": 330 },
{ "name": "Serum Magnesium", "price": 500 },
{ "name": "Serum Phosphorus", "price": 220 },
{ "name": "Serum PROTEIN - TOTAL", "price": 200 },
{ "name": "Serum Protein Electrophoresis", "price": 820 },
{ "name": "Serum Triglycerides", "price": 200 },
{ "name": "Serum Zinc Test", "price": 410 },
{ "name": "Sickle Cell Test", "price": 300 },
{ "name": "Sodium", "price": 200 },
{ "name": "Thyroid Peroxidase (TPO) Antibody", "price": 1200 },
{ "name": "Thyroid Profile (TFT)", "price": 360 },
{ "name": "Thyroid Stimulating Hormone (TSH)", "price": 200 },
{ "name": "TORCH 10", "price": 2100 },
{ "name": "Testosterone Test", "price": 600 },
{ "name": "TIBC (Total Iron Binding Capacity)", "price": 300 },
{ "name": "Total Cholesterol", "price": 200 },  // Price not provided
{ "name": "Total IgE", "price": 700 },
{ "name": "Total Protein", "price": 200 },
{ "name": "TREPONEMA PALLIDUM HAEMAGGLUTINATION(TPHA)", "price": 520 },
{ "name": "T3", "price": 200 },
{ "name": "T4", "price": 200 },
{ "name": "T3, T4, TSH", "price": 360 },
{ "name": "Triglycerides", "price": 200 },
{ "name": "Troponin I Rapid Test", "price": 520 },
{ "name": "Typhoid Test (Widal Test)", "price": 200 },
{ "name": "Urine Culture", "price": 800 },
{ "name": "Urine Routine (Urinalysis)", "price": 150 },
{ "name": "Uric Acid Test", "price": 200 },
{ "name": "Vitamin B12", "price": 750 },
{ "name": "Vitamin B6", "price": 1050 },
{ "name": "Vitamin D", "price": 750 },
{ "name": "Vitamin D3", "price": 1800 },
{ "name": "VDRL", "price": 210 }
    ],
    "redcliffe": [
        { "name": "17-Alpha Hydroxyprogesterone test", "price": 1400},
{ "name": "Activated Partial Thromboplastin Time (APTT)", "price": 499 },
{ "name": "Albumin", "price": 149 },
{ "name": "Total Protein&Albumin/Globulin (ag) Ratio Test ", "price": 149 },
{ "name": "Alkaline Phosphatase (ALP) Test", "price": 149 },
{ "name": "Alkaline Phosphatase Isoenzymes", "price": 5600 },
{ "name": "Alpha-1 Antitrypsin Test", "price": 2200},
{ "name": "Alpha-feto protein (AFP) test CSF", "price": 950 },
{ "name": "Pancreatitis Amylase test", "price": 400 },
{ "name": "Anti nuclear antibody(ANA) test by IFA(HEP-2)", "price": 950 },
{ "name": "Anti-Phospholipid Antibody IgG Test", "price": 900 },
{ "name": "Anti-Phospholipid Antibody IgM Test", "price": 900 },
{ "name": " Anti-Cyclic Citrullinated Peptide antibodies test (Anti-CCP)", "price": 1549 },
{ "name": "Anti Double Stranded DNA (DsDNA) Test By IFA", "price": 1999 },
{ "name": "Anti-Mullerian Hormone (AMH)", "price": 1799},
{ "name": "HIV 1&2 Antibodies Test by CMIA Method", "price": 499 },
{ "name": "Antenatal Care Profile (ANC)- Advance", "price": 1899 },
{ "name": "Beta 2 Microglobulin, Serum Test", "price": 1400},
{ "name": "Bilirubin Direct test", "price": 150 },
{ "name": "Bilirubin (total, direct & indirect)", "price": 220 },
{ "name": "Bilirubin total Test", "price": 140 },
{ "name": "Blood Group Test", "price": 170},
{ "name": "Lactate Dehydrogenase (LDH), Serum Test", "price": 330},
{ "name": "Lead, WB EDTA Test", "price": 1800},
{ "name": "Blood Sugar (Glucose Fasting)", "price": 80 },
{ "name": "Blood Sugar (Glucose PP)", "price": 80 },
{ "name": "Blood Urea Nitrogen (BUN)", "price": 150},
{ "name": "Bence Jones Protein Test", "price": 600 },
{ "name": "C-Reactive Protein (CRP)", "price": 400 },
{ "name": "C-reactive Protein High Sensitivity (HS-CRP)", "price": 700 },
{ "name": "Carcinoembryonic Antigen (CEA) Test", "price": 740 },
{ "name": "CA 125 Test", "price": 1200},
{ "name": "Calcium Test", "price": 200 },
{ "name": "CBC (Complete Blood Count)", "price": 190 },
{ "name": "Chloride Test", "price": 140 },
{ "name": "Cholesterol total body fluid test", "price":  250},
{ "name": "Pseudo Cholinesterase OPC poisoning Test", "price": 540 },
{ "name": "Cortisol Morning Sample Test", "price": 590 },
{ "name": "Serum Creatinine", "price": 150 },
{ "name": "Cystatin C Test", "price": 1200},
{ "name": "D-dimer Test", "price": 1000 },
{ "name": "dehydroepiandrosterone-sulfate (dheas) Test", "price": 1000 },
{ "name": "Dengue IgM Antibody Test EIA", "price": 600 },
{ "name": "Dengue NS1 Antigen Test by ELISA", "price": 590},
{ "name": "Dopamine Test", "price": 2400 },
{ "name": "Electrolytes (Na/K/Cl) Test", "price": 350 },
{ "name": "Estradiol Test (E2)", "price": 570 },
{ "name": "Erythrocyte Sedimentation Rate (ESR)", "price": 130 },
{ "name": "Ferritin Test", "price": 500 },
{ "name": "Folic Acid Test", "price": 1000},
{ "name": "Follicle Stimulating Hormone FSH Test", "price": 550 },
{ "name": "Free Testosterone", "price": 1500},
{ "name": "FT3 (Free Triiodothyronine)", "price": 300 },
{ "name": "FT4 (Free Thyroxine)", "price": 300 },
{ "name": "Gamma-Glutamyl Transferase (GGT)", "price": 260 },
{ "name": "Estimated Glomerular Filtration Rate (eGFR) Test", "price":  220},
{ "name": "Glycated Hemoglobin (HbA1c)", "price": 350 },
{ "name": "G6PD, Qualitative (Glucose-6-Phosphate Dehydrogenase) Test", "price": 750 },
{ "name": "Helicobacter Pylori IgG Antibodies Test", "price": 1800 },
{ "name": "Helicobacter Pylori IgM Antibodies Test", "price": 1800 },
{ "name": "Hemoglobin", "price": 140 },
{ "name": "Hepatitis B Surface Antigen (HBsAg) Rapid Card Test", "price": 350 },
{ "name": "Hepatitis C antibody (HCV) Test - Rapid card", "price": 300 },
{ "name": "HLA B27 (Flow Cytometry) Test", "price": 2400 },
{ "name": "Homocysteine Test", "price": 900 },
{ "name": "Immunoglobulin A (IgA) Test", "price": 500 },
{ "name":"Immunoglobulin A (IgA) Test ", "price": 500},
{ "name": "IgE Total Test", "price": 600 },
{ "name": "Inhibin A (Dimeric) Test", "price": 800 },
{ "name": "Iron Test", "price": 300 },
{ "name": "Kidney Function Test (KFT)(RFT)",
  "price": 350 },
{ "name": "Lactate Dehydrogenase (LDH), Serum Test", "price": 330 },
{ "name": "Pancreatitis Lipase Test", "price": 600 },
{ "name": "Lipid Profile", "price": 320 },
{ "name": "Lipoprotein(a) Test", "price": 900 },
{ "name": "Liver Function Test (LFT)", "price": 370 },
{ "name": "Luteinizing Hormone (LH)", "price": 500 },
{ "name": "Malaria Parasite Test", "price": 150 },
{ "name": "Microscopic Urine Examination", "price": 150 },
{ "name": "Myoglobin, Serum Test", "price": 4300 },
{ "name": "PAP (Papanicolaou) Smear Test", "price": 550 },
{ "name": "Platelet Count", "price": 200 },
{ "name": "Potassium", "price": 160 },
{ "name": "Procalcitonin (pct) Test", "price": 3000 },
{ "name": "Prolactin Test", "price": 550 },
{ "name": "Prostate Specific Antigen (PSA) Free Test", "price": 850 },
{ "name": "Protein Electrophoresis, Serum Test", "price": 699 },
{ "name": "Quantiferon TB IGRA Test", "price": 2399 },
{ "name": "RA (Rheumatoid Factor)", "price": 400 },
{ "name": "Paracetamol Test", "price": 1000 },
{ "name": "Creatine Phosphokinase (CPK)Test", "price": 299 },
{ "name": "Magnesium Test", "price": 350 },
{ "name": " Phosphorus Test", "price": 170 },
{ "name": "Total protein Test", "price": 125 },
{ "name": "Protein Electrophoresis, Serum Test", "price": 699 },
{ "name": "Serum Triglycerides", "price": 250 },
{ "name": "Zinc Test", "price": 1800},
{ "name": "Sodium", "price": 149 },
{ "name": "Anti Thyroid Peroxidase Antibodies (TPO) Test", "price": 1199},
{ "name": "Thyroid Profile (TFT)", "price": 299 },
{ "name": "Thyroid Stimulating Hormone (TSH)", "price": 249 },
{ "name": "Torch Panel IgG & IgM Test (10 Parameters)", "price": 2999 },
{ "name": "Testosterone Total Test", "price": 449 },
{ "name": "Total Cholesterol", "price": 150 },  // Price not provided
{ "name": "Total IgE", "price": 599 },
{ "name": "Total Protein", "price": 125 },
{ "name": "Treponema pallidium hemagglutination assay (tpha) Test", "price": 550 },
{ "name": "T3", "price": 200 },
{ "name": "T4", "price": 200 },
{ "name": "Troponin I Rapid Test", "price": 1350 },
{ "name": "Typhoid Test (Widal Test)", "price": 199},
{ "name": "Urine Culture", "price": 699 },
{ "name": "Urine Routine (Urinalysis)", "price": 199 },
{ "name": "Uric Acid Test", "price": 160 },
{ "name": "Vitamin B12", "price": 549 },
{ "name": "Vitamin B6 (Pyridoxine) Test", "price": 3700},
{ "name": "Vitamin D", "price": 499 },
{ "name": "VDRL", "price": 229 }
    ],
    "kk_lab": [
      
    { "name": "CBC", "price": 100 },
    { "name": "ESR", "price": 100 },
    { "name": "Malaria Parasite", "price": 50 },
    { "name": "Reticulocyte Count", "price": 400 },
    { "name": "Platelet Count", "price": 100 },
    { "name": "PTINR", "price": 500 },
    { "name": "B.T. & C.T.", "price": 150 },
    { "name": "Blood Group & Rh Factor", "price": 50 },
    { "name": "Urine Routine", "price": 50 },
    { "name": "Stool Routine", "price": 150 },
    { "name": "Pregnancy Test", "price": 150 },
    { "name": "Semen Examination", "price": 200 },
    { "name": "Mantoux Test", "price": 100 },
    { "name": "Widal Test (typhoid)", "price": 100 },
    { "name": "VDRL Test", "price": 200 },
    { "name": "A.S.O. Test", "price": 350 },
    { "name": "R.A. Test", "price": 200 },
    { "name": "HBSAG", "price": 200 },
    { "name": "HIV", "price": 300 },
    { "name": "H.C.V.", "price": 600 },
    { "name": "CR.P.", "price": 600 },
    { "name": "G.6.P.D", "price": 350 },
    { "name": "CPK-MB", "price": 800 },
    { "name": "LDH", "price": 400 },
    { "name": "Leptospira", "price": 1000 },
    { "name": "Dengue Combo.", "price": 600 },
    { "name": "BSF", "price": 50 },
    { "name": "BSPP", "price": 50 },
    { "name": "BSR", "price": 50 },
    { "name": "GTT", "price": 550 },
    { "name": "Blood Urea", "price": 150 },
    { "name": "Serum Creatinine", "price": 100 },
    { "name": "Serum Cholesterol", "price": 200 },
    { "name": "Serum Bilirubin", "price": 150 },
    { "name": "SGOT", "price": 150 },
    { "name": "SGPT", "price": 150 },
    { "name": "Serum Alkaline Phosphatase", "price": 250 },
    { "name": "Serum Protein (T.PR+ALB.)", "price": 250 },
    { "name": "Serum Calcium", "price": 200 },
    { "name": "Serum Triglycerides", "price": 200 },
    { "name": "HDL Cholesterol", "price": 200 },
    { "name": "LDL Cholesterol", "price": 200 },
    { "name": "Serum Uric Acid", "price": 100 },
    { "name": "Serum Electrolytes", "price": 550 },
    { "name": "Liver Function Test (L.F.T)", "price": 750 },
    { "name": "Kidney Function Test (RFT)(KFT)", "price": 750 },
    { "name": "Lipid Profile Test (L.P.T)", "price": 750 },
    { "name": "Sputum for AFB", "price": 300 },
    { "name": "HbA1c", "price": 550 },
    { "name": "Malarial Antigen", "price": 300 }
]

};

// Function to search blood tests
// Default selected lab is Thyrocare
let selectedLab = "redcliffe";

// Function to update test list based on selected lab
function updateTestsBasedOnLab() {
    selectedLab = document.getElementById('lab-selection').value;
    searchBloodTest();  // Update the blood test list when lab is changed
}

// Function to search and filter blood tests based on lab
function searchBloodTest() {
    const query = document.getElementById('search-bar').value.toLowerCase();
    const results = document.getElementById('search-results');
    
    const filteredTests = bloodTestsByLab[selectedLab].filter(test => test.name.toLowerCase().includes(query));

    results.innerHTML = '';
    
    if (filteredTests.length > 0) {
        results.style.display = 'block';
        filteredTests.forEach(test => {
            const resultDiv = document.createElement('div');
            resultDiv.classList.add('result');
            resultDiv.innerHTML = `
                <span>${test.name} - ₹${test.price}</span>
                <button onclick="addToCart('${test.name}', ${test.price})">Add to Cart</button>
            `;
            results.appendChild(resultDiv);
        });
    } else {
        results.style.display = 'none';
    }
}

// Cart array
let cart = [];


// Function to load cart from localStorage when the page loads
window.addEventListener('load', function() {
    const savedCart = localStorage.getItem('cart');
    if (savedCart) {
        cart = JSON.parse(savedCart);  // Parse the cart items from localStorage
        updateCart();  // Update the cart icon and popup with the loaded cart
    }
});

// Function to add an item to the cart
function addToCart(name, price) {
    // Check if the test is already in the cart
    const testExists = cart.some(item => item.name === name);

    if (testExists) {
        alert('Oh! You have already added this test to the cart.');
    } else {
        // If not, add it to the cart
        cart.push({ name, price });
        updateCart();  // Update the UI and cart data in localStorage
    }
}

// Update the cart icon with the number of items in the cart
function updateCart() {
    const cartCount = document.getElementById('cart-count');
    cartCount.textContent = cart.length;  // Update the cart count in the UI
    updateCartPopup();  // Update the cart popup UI

    // Save the cart to localStorage
    localStorage.setItem('cart', JSON.stringify(cart));
}

// Function to update the cart popup
// Function to update the cart popup based on the selected lab
function updateCartPopup() {
    const cartItems = document.getElementById('cart-items');
    const cartTotal = document.getElementById('cart-total');
    const homeVisitCharge = document.getElementById('home-visit-charge');
    const remainingAmountMessage = document.getElementById('remaining-amount-message');
    const whatsappButton = document.getElementById('whatsapp-booking');
    const hardcopyCheckbox = document.getElementById('hardcopy-checkbox');
    const hardcopyMessage = document.getElementById('hardcopy-message');

    cartItems.innerHTML = ''; // Clear the cart items display
    let total = 0;
    let cartMessage = `I would like to book the following tests from ${capitalizeFirstLetter(selectedLab)}:\n`; // Include the lab name

    cart.forEach((item, index) => {
        const li = document.createElement('li');
        li.textContent = `${item.name} - ₹${item.price}`;
        
        const removeIcon = document.createElement('i');
        removeIcon.classList.add('fas', 'fa-times', 'remove-icon');
        removeIcon.onclick = function () {
            removeFromCart(index);
        };
        
        li.appendChild(removeIcon);
        cartItems.appendChild(li);
        
        total += item.price;
        cartMessage += `${item.name} - ₹${item.price}\n`;
    });

    let homeVisit = 0;

    // Check if the selected lab is RedCliffe
    if (selectedLab === "redcliffe") {
        if (total < 1500 && total > 0) {
            homeVisit = 50; // RedCliffe has a home visit charge of ₹200 if total is below ₹1500
            homeVisitCharge.textContent = `Home Visit Charge: ₹${homeVisit}`;
            remainingAmountMessage.textContent = ''; // No need to display "add more" message for RedCliffe
        } else {
            homeVisitCharge.textContent = `Home Visit Charge: ₹0`; // No charge if total is ₹1500 or more
            remainingAmountMessage.textContent = '';
        }
    } else if (total < 549 && total > 0) {
        homeVisit = 50; // For other labs (like Thyrocare or K.K Lab), set the charge to ₹89 if total is below ₹549
        homeVisitCharge.textContent = `Home Visit Charge: ₹${homeVisit}`;
        remainingAmountMessage.textContent = `Add ₹${549 - total} more to avoid the home visit charge.`;
    } else {
        homeVisitCharge.textContent = `Home Visit Charge: ₹0`; // No charge if total is ₹549 or more for other labs
        remainingAmountMessage.textContent = '';
    }

    let hardcopyCharge = 0;
    if (hardcopyCheckbox.checked) {
        hardcopyCharge = 100;
        hardcopyMessage.textContent = "Hardcopy report will be delivered to your home (+₹100)";
    } else {
        hardcopyMessage.textContent = '';
    }

    const finalTotal = total + homeVisit + hardcopyCharge;
    cartTotal.textContent = finalTotal;

    cartMessage += `\nHome Visit Charge: ₹${homeVisit}`;
    if (hardcopyCharge > 0) {
        cartMessage += `\nHardcopy Report: ₹${hardcopyCharge}`;
    }
    cartMessage += `\nTotal: ₹${finalTotal}`;
    const whatsappLink = `https://wa.me/7559445660?text=${encodeURIComponent(cartMessage)}`;
    whatsappButton.setAttribute('href', whatsappLink);
}

// Helper function to capitalize the first letter of lab name
function capitalizeFirstLetter(str) {
    return str.charAt(0).toUpperCase() + str.slice(1);
}


// Function to remove an item from the cart
function removeFromCart(index) {
    // Remove the item from the cart
    cart.splice(index, 1);

    // Update the cart and its content
    updateCart();
    updateCartPopup();

    // Ensure the cart stays open if it was previously open
    const cartPopup = document.getElementById('cart-popup');
    if (!cartPopup.classList.contains('active')) {
        cartPopup.classList.add('active'); // Keep the cart popup active (open)
    }

    // Save updated cart to localStorage
    localStorage.setItem('cart', JSON.stringify(cart));
}

// Function to clear the cart
function clearCart() {
    cart = [];
    updateCart();
    localStorage.removeItem('cart');
}


// Close search results if clicked outside
document.addEventListener('click', function(event) {
    const searchResults = document.getElementById('search-results');
    const searchBar = document.getElementById('search-bar');
    if (!searchResults.contains(event.target) && event.target !== searchBar) {
        searchResults.style.display = 'none';
    }
});


// Predefined Service Areas
const serviceAreas = [
    "Bhiwandi","Kalyan","Thane", "Mumbai","Mumbra"
];

// Show/Hide service area results based on search
function showResults() {
    const query = document.getElementById("searchInput").value.toLowerCase();
    const filteredAreas = serviceAreas.filter(area => area.toLowerCase().includes(query));

    const resultsDiv = document.getElementById("serviceAreaResults");
    resultsDiv.innerHTML = '';

    if (filteredAreas.length > 0 && query) {
        resultsDiv.classList.add('active-results');
        resultsDiv.style.display = 'block';  // Show suggestions

        filteredAreas.forEach(area => {
            const div = document.createElement('div');
            div.textContent = area;
            div.onclick = function() { selectServiceArea(area); };
            resultsDiv.appendChild(div);
        });
    } else if (query) {
        // No suggestions found, show "Coming Soon" or "Service not available"
        resultsDiv.style.display = 'block';  // Show empty results (suggestion)
        const div = document.createElement('div');
        div.textContent = 'No service available for this area, but we are coming soon!';
        div.style.color = '#FF6347'; // Color for unavailable
        resultsDiv.appendChild(div);
    } else {
        resultsDiv.style.display = 'none';  // Hide suggestions if query is empty
    }
}

// Handle selecting a service area
function selectServiceArea(area) {
    document.getElementById("searchInput").value = area;
    document.getElementById("serviceAreaResults").classList.remove('active-results');
    document.getElementById("serviceAreaResults").style.display = 'none'; // Hide suggestions after selection

    // Check if service is available or not
    if (isServiceAvailable(area)) {
        showPopup(`Yes! Our service is available in ${area}.`);
    } else {
        showPopup(`Coming soon in ${area}.`);
    }
}

// Check if the service area is available
function isServiceAvailable(area) {
    return serviceAreas.includes(area); // Returns true or false
}

// Show the pop-up with the message (for available or unavailable area)
function showPopup(message) {
    const popup = document.getElementById("popupNotification");
    const popupMessage = document.getElementById("popupMessage");
    const popupButton = document.getElementById("popupButton");

    popupMessage.textContent = message;
    popup.style.display = 'block';  // Show pop-up

    // Close the pop-up when button is clicked
    popupButton.onclick = function() {
        popup.style.display = 'none';
    };
}

// Image Slider Navigation

// FAQ Section 
// JavaScript to toggle FAQ answers and language
const faqItems = document.querySelectorAll('.faq-item');
const langButtons = document.querySelectorAll('.lang-btn');

const toggleLanguage = (language) => {
    const allTextElements = document.querySelectorAll('[data-en], [data-es]');
    
    allTextElements.forEach(element => {
        if (language === 'en') {
            element.textContent = element.getAttribute('data-en');
        } else {
            element.textContent = element.getAttribute('data-es');
        }
    });
};

langButtons.forEach(button => {
    button.addEventListener('click', () => {
        langButtons.forEach(btn => btn.classList.remove('active'));
        button.classList.add('active');
        
        const language = button.id.split('-')[1];
        toggleLanguage(language);
    });
});

// FAQ toggle functionality with smooth transitions
faqItems.forEach(item => {
    const question = item.querySelector('.faq-question');
    const answer = item.querySelector('.faq-answer');
    const icon = question.querySelector('.icon');

    question.addEventListener('click', () => {
        const isVisible = answer.style.display === 'block';

        if (isVisible) {
            // Collapse the answer
            answer.classList.remove('expanded');
            answer.style.display = 'none'; // Hide the content
            icon.textContent = '+'; // Change icon to "+"
            icon.style.transform = 'rotate(0deg)'; // Reset the rotation
        } else {
            // Expand the answer
            answer.style.display = 'block'; // Make the content visible
            setTimeout(() => { 
                answer.classList.add('expanded'); // Add padding and expand the content
            }, 10); // Small delay to trigger the transition

            icon.textContent = '−'; // Change icon to "−"
            icon.style.transform = 'rotate(45deg)'; // Rotate icon 45 degrees for smooth effect
        }
    });
});


// Packages

  // Select the scrollable container and the arrow elements
  const scrollContainer = document.querySelector('.packages-container');
  const scrollLeft = document.querySelector('.scroll-indicator-left');
  const scrollRight = document.querySelector('.scroll-indicator-right');

  // Scroll left on click
  scrollLeft.addEventListener('click', () => {
    scrollContainer.scrollBy({
      left: -300, // Amount to scroll left
      behavior: 'smooth' // Smooth scrolling
    });
  });

  // Scroll right on click
  scrollRight.addEventListener('click', () => {
    scrollContainer.scrollBy({
      left: 300, // Amount to scroll right
      behavior: 'smooth' // Smooth scrolling
    });
  });
  //image slider

let currentIndex = 0;
const slides = document.querySelectorAll('.carousel-slide');
const dots = document.querySelectorAll('.dot');
const carouselWrapper = document.querySelector('.carousel-wrapper');
let startX = 0;
let endX = 0;
let autoSlideInterval;

// Function to display a specific slide
function showSlide(index) {
    // Ensure the slide index is within range
    currentIndex = (index + slides.length) % slides.length;
    carouselWrapper.style.transform = `translateX(-${currentIndex * 100}%)`;

    // Update dots
    dots.forEach(dot => dot.classList.remove('active'));
    dots[currentIndex].classList.add('active');
}

// Function to move to the next or previous slide
function moveSlide(step) {
    showSlide(currentIndex + step);
}

// Go to a specific slide
function goToSlide(index) {
    showSlide(index);
}

// Swipe functionality
carouselWrapper.addEventListener('touchstart', (e) => {
    startX = e.touches[0].clientX;
    stopAutoSlide(); // Stop auto-slide when user interacts
});

carouselWrapper.addEventListener('touchmove', (e) => {
    endX = e.touches[0].clientX;
});

carouselWrapper.addEventListener('touchend', () => {
    if (startX - endX > 50) {
        // Swiped left (move to next slide)
        moveSlide(1);
    } else if (endX - startX > 50) {
        // Swiped right (move to previous slide)
        moveSlide(-1);
    }
    startAutoSlide(); // Restart auto-slide after user interaction
});

// Auto-slide functionality (Slower auto-slide)
function startAutoSlide() {
    autoSlideInterval = setInterval(() => moveSlide(1), 8000); // Auto-slide every 8 seconds (slower)
}

function stopAutoSlide() {
    clearInterval(autoSlideInterval);
}

// Initialize the carousel with slower auto-slide
setInterval(() => moveSlide(1), 5000); // Auto-slide every 5 seconds (slower)
showSlide(currentIndex); // Initialize the carousel display

// Pause auto-slide on interaction (touch)
carouselWrapper.addEventListener('touchstart', stopAutoSlide);
carouselWrapper.addEventListener('touchend', startAutoSlide);

// For mouse interactions (if needed for desktops/laptops)
carouselWrapper.addEventListener('mouseover', stopAutoSlide);
carouselWrapper.addEventListener('mouseout', startAutoSlide);


// location fetch
 const serviceablePincodes = {
  "421302": "Area 1",
  "400607": "Area 2",
  "400615": "Area 3",
  "400605": "Area 4",
  "421301": "Area 5"
}; // Your provided serviceable pincodes with area names

document.addEventListener("DOMContentLoaded", function() {
  // Automatically fetch location when the page loads
  getLocation();
});

function getLocation() {
  if (navigator.geolocation) {
    showLoader();
    navigator.geolocation.getCurrentPosition(showPosition, showError);
  } else {
    setStatus("Geolocation is not supported by this browser.", "error");
  }
}

function showPosition(position) {
  const lat = position.coords.latitude;
  const lon = position.coords.longitude;
  // Fetch address information using Nominatim API
  fetch(`https://nominatim.openstreetmap.org/reverse?format=json&lat=${lat}&lon=${lon}`)
    .then(response => response.json())
    .then(data => {
      const components = data.address;
      const pincode = components.postcode;
      const areaName = components.city || components.town || components.village;
      checkServiceAvailability(pincode, areaName);
      hideLoader();
    })
    .catch(error => {
      console.error("Error fetching geolocation data:", error);
      setStatus("Error fetching location data. Please try again.", "error");
      hideLoader();
    });
}

function checkServiceAvailability(pincode, areaName) {
  if (serviceablePincodes[pincode]) {
    setStatus(`Congratulations 😊 Service is available in ${areaName} (Pincode: ${pincode}).`, "success");
  } else {
    setStatus(`Sorry Service is not available for ${areaName} (Pincode: ${pincode}).still you can get in touch with us`, "error");
  }
}

function showError(error) {
  console.error("Geolocation error:", error);
  setStatus("An error occurred while fetching your location.", "error");
  hideLoader();
}

function setStatus(message, type) {
  const statusElement = document.getElementById("status");
  statusElement.innerHTML = message;
  statusElement.className = type; // Set the class based on the status type (success or error)
}

function showLoader() {
  document.getElementById("loader").style.display = "block";
  document.getElementById("status").style.display = "none";
}

function hideLoader() {
  document.getElementById("loader").style.display = "none";
  document.getElementById("status").style.display = "block";
}


