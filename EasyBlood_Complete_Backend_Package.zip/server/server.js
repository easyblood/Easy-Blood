import express from "express";
import cors from "cors";
import bcrypt from "bcryptjs";
import jwt from "jsonwebtoken";
import Database from "better-sqlite3";
import multer from "multer";
import crypto from "crypto";
import path from "path";
import fs from "fs";

const app = express();
const PORT = process.env.PORT || 3000;
const JWT_SECRET = process.env.JWT_SECRET || "CHANGE_THIS_SECRET_BEFORE_PRODUCTION";

app.use(cors());
app.use(express.json({limit:"2mb"}));

const db = new Database(process.env.DB_FILE || "./easyblood.db");
db.pragma("journal_mode = WAL");

db.exec(`
CREATE TABLE IF NOT EXISTS users (
 id INTEGER PRIMARY KEY AUTOINCREMENT,
 login_id TEXT UNIQUE NOT NULL,
 password_hash TEXT NOT NULL,
 role TEXT NOT NULL CHECK(role IN ('management','staff')),
 active INTEGER NOT NULL DEFAULT 1,
 created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);
CREATE TABLE IF NOT EXISTS reports (
 id INTEGER PRIMARY KEY AUTOINCREMENT,
 report_id TEXT UNIQUE NOT NULL,
 patient_id TEXT NOT NULL,
 patient_name TEXT NOT NULL,
 age TEXT,
 gender TEXT,
 mobile TEXT,
 test_name TEXT NOT NULL,
 result_json TEXT NOT NULL,
 barcode TEXT,
 report_date TEXT NOT NULL,
 verified INTEGER NOT NULL DEFAULT 1,
 pdf_url TEXT,
 verify_token TEXT UNIQUE NOT NULL,
 created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);
`);

const count = db.prepare("SELECT COUNT(*) c FROM users").get().c;
if (!count) {
  const mg = bcrypt.hashSync(process.env.MANAGEMENT_PASSWORD || "easyblood123", 12);
  const st = bcrypt.hashSync(process.env.STAFF_PASSWORD || "staff123", 12);
  db.prepare("INSERT INTO users(login_id,password_hash,role) VALUES(?,?,?)").run("easyblood",mg,"management");
  db.prepare("INSERT INTO users(login_id,password_hash,role) VALUES(?,?,?)").run("staff",st,"staff");
}

function auth(req,res,next){
  const h=req.headers.authorization||"";
  if(!h.startsWith("Bearer ")) return res.status(401).json({error:"Unauthorized"});
  try { req.user=jwt.verify(h.slice(7),JWT_SECRET); next(); }
  catch { res.status(401).json({error:"Invalid or expired token"}); }
}
function management(req,res,next){
  if(req.user.role!=="management") return res.status(403).json({error:"Management access required"});
  next();
}

app.get("/api/health",(req,res)=>res.json({ok:true,service:"Easy Blood"}));

app.post("/api/auth/login",(req,res)=>{
  const {login_id,password}=req.body||{};
  const u=db.prepare("SELECT * FROM users WHERE login_id=? AND active=1").get(login_id||"");
  if(!u || !bcrypt.compareSync(password||"",u.password_hash))
    return res.status(401).json({error:"Incorrect Login ID or Password"});
  const token=jwt.sign({id:u.id,login_id:u.login_id,role:u.role},JWT_SECRET,{expiresIn:"8h"});
  res.json({token,role:u.role,login_id:u.login_id});
});

app.post("/api/users",auth,management,(req,res)=>{
  const {login_id,password,role="staff"}=req.body||{};
  if(!login_id||!password||!["staff"].includes(role)) return res.status(400).json({error:"Invalid user"});
  try {
    const hash=bcrypt.hashSync(password,12);
    const info=db.prepare("INSERT INTO users(login_id,password_hash,role) VALUES(?,?,?)").run(login_id,hash,role);
    res.status(201).json({id:info.lastInsertRowid,login_id,role});
  } catch { res.status(409).json({error:"Login ID already exists"}); }
});

app.post("/api/reports",auth,(req,res)=>{
  const r=req.body||{};
  if(!r.patient_name||!r.test_name) return res.status(400).json({error:"Patient name and test name are required"});
  const reportId="EB-"+crypto.randomBytes(6).toString("hex").toUpperCase();
  const patientId=r.patient_id||"EBP-"+crypto.randomBytes(5).toString("hex").toUpperCase();
  const token=crypto.randomBytes(24).toString("base64url");
  db.prepare(`INSERT INTO reports
  (report_id,patient_id,patient_name,age,gender,mobile,test_name,result_json,barcode,report_date,verify_token)
  VALUES(?,?,?,?,?,?,?,?,?,?,?)`).run(
    reportId,patientId,r.patient_name,r.age||"",r.gender||"",r.mobile||"",r.test_name,
    JSON.stringify(r.result||[]),r.barcode||reportId,r.report_date||new Date().toISOString().slice(0,10),token
  );
  res.status(201).json({report_id:reportId,patient_id:patientId,verify_token:token});
});

app.get("/api/reports",auth,(req,res)=>{
  const rows=db.prepare(`SELECT report_id,patient_id,patient_name,age,gender,test_name,barcode,report_date,verified,created_at FROM reports ORDER BY id DESC`).all();
  res.json(rows);
});

app.get("/api/reports/:reportId",auth,(req,res)=>{
  const r=db.prepare("SELECT * FROM reports WHERE report_id=?").get(req.params.reportId);
  if(!r) return res.status(404).json({error:"Report not found"});
  r.result=JSON.parse(r.result_json); delete r.result_json; delete r.verify_token;
  res.json(r);
});

app.get("/api/reports/verify/:token",(req,res)=>{
  const r=db.prepare("SELECT report_id,patient_id,patient_name,age,gender,test_name,result_json,barcode,report_date,verified FROM reports WHERE verify_token=? AND verified=1").get(req.params.token);
  if(!r) return res.status(404).json({error:"Report not found or not verified"});
  r.result=JSON.parse(r.result_json); delete r.result_json;
  res.json(r);
});

const uploadDir=path.resolve("./uploads"); fs.mkdirSync(uploadDir,{recursive:true});
const upload=multer({dest:uploadDir,limits:{fileSize:10*1024*1024},fileFilter:(req,file,cb)=>cb(null,file.mimetype==="application/pdf")});
app.post("/api/reports/:reportId/pdf",auth,upload.single("pdf"),(req,res)=>{
  if(!req.file) return res.status(400).json({error:"PDF required"});
  const r=db.prepare("SELECT id FROM reports WHERE report_id=?").get(req.params.reportId);
  if(!r) return res.status(404).json({error:"Report not found"});
  const publicUrl=`/uploads/${path.basename(req.file.path)}`;
  db.prepare("UPDATE reports SET pdf_url=? WHERE report_id=?").run(publicUrl,req.params.reportId);
  res.json({pdf_url:publicUrl});
});

app.use("/uploads",express.static(uploadDir,{index:false}));
app.listen(PORT,()=>console.log(`Easy Blood API running on port ${PORT}`));
