const express=require("express");
const cors=require("cors");
const fs=require("fs");
const path=require("path");
const multer=require("multer");
const jwt=require("jsonwebtoken");
const bcrypt=require("bcryptjs");

const app=express();
app.disable("x-powered-by");
app.use((req,res,next)=>{res.setHeader("X-Content-Type-Options","nosniff");res.setHeader("Referrer-Policy","no-referrer");res.setHeader("X-Frame-Options","DENY");next()});
const PORT=process.env.PORT||3000;
const requiredEnv=["JWT_SECRET","MANAGEMENT_ID","MANAGEMENT_PASS","STAFF_ID","STAFF_PASS"];
const missingEnv=requiredEnv.filter(k=>!process.env[k]);
if(missingEnv.length) throw new Error("Missing required environment variables: "+missingEnv.join(", "));
if(process.env.JWT_SECRET.length<32) throw new Error("JWT_SECRET must be at least 32 characters");
if(process.env.MANAGEMENT_PASS.length<12 || process.env.STAFF_PASS.length<12) throw new Error("Management and Staff passwords must each be at least 12 characters");
const JWT_SECRET=process.env.JWT_SECRET;
const ADMIN_ID=process.env.MANAGEMENT_ID;
const ADMIN_HASH=bcrypt.hashSync(process.env.MANAGEMENT_PASS,12);
const STAFF_ID=process.env.STAFF_ID;
const STAFF_HASH=bcrypt.hashSync(process.env.STAFF_PASS,12);

const dataDir=process.env.DATA_DIR||path.join(__dirname,"data");
const uploadDir=process.env.UPLOAD_DIR||path.join(dataDir,"uploads");
fs.mkdirSync(dataDir,{recursive:true}); fs.mkdirSync(uploadDir,{recursive:true});
const dbFile=path.join(dataDir,"reports.json");
if(!fs.existsSync(dbFile)) fs.writeFileSync(dbFile,"[]");

app.use(express.json({limit:"2mb"}));
app.use(express.urlencoded({extended:true}));
app.use(express.static(path.join(__dirname,"public")));

const storage=multer.diskStorage({
  destination:(req,file,cb)=>cb(null,uploadDir),
  filename:(req,file,cb)=>cb(null,Date.now()+"-"+file.originalname.replace(/[^a-zA-Z0-9._-]/g,"_"))
});
const upload=multer({storage,limits:{fileSize:15*1024*1024},fileFilter:(req,file,cb)=>{
  cb(file.mimetype==="application/pdf"?null:new Error("Only PDF files are allowed"),file.mimetype==="application/pdf");
}});

function readReports(){try{return JSON.parse(fs.readFileSync(dbFile,"utf8"))}catch{return []}}
function writeReports(x){fs.writeFileSync(dbFile,JSON.stringify(x,null,2))}
function makeId(){return "EB-"+Date.now().toString(36).toUpperCase()+"-"+Math.random().toString(36).slice(2,8).toUpperCase()}
function makeUHID(){return "EBP-"+Date.now().toString(36).toUpperCase()}
function auth(req,res,next){
  const h=req.headers.authorization||"";
  if(!h.startsWith("Bearer ")) return res.status(401).json({error:"Login required"});
  try{req.user=jwt.verify(h.slice(7),JWT_SECRET);next()}catch{return res.status(401).json({error:"Session expired"})}
}
function safeUser(id,pass){
  if(id===ADMIN_ID && bcrypt.compareSync(pass,ADMIN_HASH)) return {role:"management"};
  if(id===STAFF_ID && bcrypt.compareSync(pass,STAFF_HASH)) return {role:"staff"};
  return null;
}

const loginAttempts=new Map();
app.post("/api/login",(req,res)=>{
  const ip=req.ip||req.socket.remoteAddress||"unknown";
  const now=Date.now();
  const entry=loginAttempts.get(ip)||{count:0,until:now+15*60*1000};
  if(now>entry.until){entry.count=0;entry.until=now+15*60*1000;}
  if(entry.count>=10)return res.status(429).json({error:"Too many login attempts. Try again in 15 minutes."});
  const u=safeUser(String(req.body.id||"").trim(),String(req.body.password||""));
  if(!u){entry.count++;loginAttempts.set(ip,entry);return res.status(401).json({error:"Incorrect Login ID or Password"});}
  loginAttempts.delete(ip);
  const token=jwt.sign(u,JWT_SECRET,{expiresIn:"8h"});
  res.json({token,role:u.role});
});

app.get("/api/reports",auth,(req,res)=>{
  let list=readReports();
  const q=String(req.query.q||"").toLowerCase().trim();
  if(q)list=list.filter(r=>[r.id,r.uhid,r.patient,r.test].join(" ").toLowerCase().includes(q));
  res.json(list);
});

app.get("/api/reports/:id",auth,(req,res)=>{
  const r=readReports().find(x=>x.id===req.params.id);
  if(!r)return res.status(404).json({error:"Report not found"});
  res.json(r);
});

app.get("/api/public/reports/:id",(req,res)=>{
  const r=readReports().find(x=>x.id===req.params.id);
  if(!r)return res.status(404).json({error:"Report not found"});
  const {id,uhid,patient,age,gender,test,date,barcode,result,verified}=r;
  res.json({id,uhid,patient,age,gender,test,date,barcode,result,verified,
    pdfUrl:r.pdfFile?("/api/public/reports/"+encodeURIComponent(r.id)+"/pdf"):null});
});

app.get("/api/public/reports/:id/pdf",(req,res)=>{
  const r=readReports().find(x=>x.id===req.params.id);
  if(!r || !r.pdfFile)return res.status(404).json({error:"PDF report not found"});
  const file=path.join(uploadDir,path.basename(r.pdfFile));
  if(!fs.existsSync(file))return res.status(404).json({error:"PDF file unavailable"});
  res.type("application/pdf");
  res.setHeader("Content-Disposition",'inline; filename="EasyBlood-'+r.id+'.pdf"');
  res.sendFile(file);
});

app.post("/api/reports",auth,upload.single("pdf"),(req,res)=>{
  const b=req.body;
  if(!b.patient||!b.test)return res.status(400).json({error:"Patient Name and Test Name are required"});
  const reports=readReports();
  const r={
    id:makeId(), uhid:String(b.uhid||makeUHID()), patient:String(b.patient),
    age:String(b.age||""), gender:String(b.gender||""), mobile:String(b.mobile||""),
    test:String(b.test), barcode:String(b.barcode||""),
    date:String(b.date||new Date().toISOString().slice(0,10)),
    type:String(b.type||"typed"), result:String(b.result||""),
    pdfName:req.file?req.file.originalname:"",
    pdfFile:req.file?req.file.filename:"",
    verified:true, createdAt:new Date().toISOString()
  };
  if(!r.barcode)r.barcode=r.id;
  reports.unshift(r);writeReports(reports);res.json(r);
});

app.delete("/api/reports/:id",auth,(req,res)=>{
  if(req.user.role!=="management")return res.status(403).json({error:"Management access required"});
  const reports=readReports(); const r=reports.find(x=>x.id===req.params.id);
  if(!r)return res.status(404).json({error:"Report not found"});
  if(r.pdfFile)try{fs.unlinkSync(path.join(uploadDir,r.pdfFile))}catch{}
  writeReports(reports.filter(x=>x.id!==req.params.id));res.json({ok:true});
});

app.get("/api/stats",auth,(req,res)=>{
  const rs=readReports(),t=new Date().toISOString().slice(0,10);
  res.json({total:rs.length,today:rs.filter(r=>r.date===t).length,
    pending:rs.filter(r=>!r.result&&!r.pdfName).length,verified:rs.filter(r=>r.verified).length});
});

app.get("/api/health",(req,res)=>res.json({ok:true,service:"Easy Blood Lab Management"}));
app.get("/verify/:id",(req,res)=>res.sendFile(path.join(__dirname,"public","verify.html")));
app.use((err,req,res,next)=>res.status(400).json({error:err.message||"Request failed"}));

app.listen(PORT,()=>console.log(`Easy Blood server running on port ${PORT}`));