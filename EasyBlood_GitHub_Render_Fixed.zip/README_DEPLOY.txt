EASY BLOOD — DEPLOYMENT PACKAGE (HARDENED CONFIGURATION)

IMPORTANT HOSTING LIMITATION
This is a Node.js/Express application, not a static HTML site. Tiiny.host static upload cannot run server.js, API login, report uploads, or the JSON database. Uploading this ZIP to Tiiny alone will NOT make the complete Lab Management system work.

WHAT WAS IMPROVED IN THIS PACKAGE
- Removed public fallback login credentials and fallback JWT secret.
- Server refuses to start unless private environment variables are configured.
- Requires passwords of at least 12 characters and JWT_SECRET of at least 32 characters.
- Added basic login-attempt throttling (10 failed attempts per IP per 15 minutes).
- Added basic security response headers and removed permissive open CORS.
- Added configurable persistent data directory.
- Original Easy Blood logo and project name are retained.

DEPLOYMENT
1. Use a Node.js host (not Tiiny static hosting or GitHub Pages).
2. Set the environment variables listed in .env.example in the host dashboard. Use unique private passwords; do not use the example placeholders.
3. Set DATA_DIR to the host's persistent disk mount path. The included render.yaml is an example for Render; its persistent disk requires a paid plan.
4. Deploy and check https://YOUR-HOST/api/health. It should return {"ok":true,...}.
5. Open https://YOUR-HOST/LabCorner.html and sign in using the IDs/passwords you privately configured.
6. Test a dummy report, QR verification, PDF upload/download, staff permissions, and management deletion before any real patient data is entered.

DATA AND PRIVACY WARNING
This version still uses a JSON file as its database and stores uploaded PDFs on disk. A persistent disk is mandatory or reports/uploads may be lost during redeploy/restart. JSON-file storage is not recommended for concurrent multi-user or production clinical use. Before using real patient data, migrate to a managed database and private object storage, configure backups, HTTPS, access logging, retention, and complete a privacy/security review.

PATIENT QR LINKS
The public verification endpoint intentionally displays report details to anyone holding the QR URL. Treat each QR link as confidential and share only with the intended patient.

LOCAL TEST
Node.js 18+: npm install; configure environment variables; npm start.
